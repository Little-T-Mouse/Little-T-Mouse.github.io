# CCC_2000_Problem_S2_Babbling_Brooks
n = int(input())
stm = []
for i in range(n):
    stm.append(int(input()))
action = []
while True:
    first = int(input())
    if first == 99:
        splitt = int(input())
        percent_right = int(input())
        temp = [first,splitt,percent_right]
        action.append(temp)
    elif first == 88:
        rejoin_right = int(input())
        temp = [first,rejoin_right]
        action.append(temp)
    else:
        break
#print(action)
for i in range(len(action)):
    if action[i][0] == 99:
        x = stm[action[i][1]-1] * (action[i][2])/100
        y = stm[action[i][1]-1] * ((100-(action[i][2]))/100)
        stm[action[i][1]-1] = x
        stm.insert(action[i][1], y)
    if action[i][0] == 88:
        stm[action[i][1]-1] += stm[action[i][1]]
        del stm[action[i][1]]
out = ''
for i in range(len(stm)):
    temp = int(stm[i])
    out += str(temp)
    if i != len(stm):
        out += ' '
print(out)
