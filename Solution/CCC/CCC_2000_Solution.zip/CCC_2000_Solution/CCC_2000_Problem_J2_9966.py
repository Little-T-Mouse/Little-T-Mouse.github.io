# CCC_2000_Problem_J2_9966
a = int(input())
b = int(input())
rev = ['0','1','6','8','9']
afe = ['0','1','9','8','6']
counter = 0
for i in range(a, b, 1):
    save = str(i)
    bu = str(i)
    pro = []
    aa = False
    for j in range(len(save)):
        pro.append(save[j])
        
    for k in range(len(pro)):
        if pro[k] not in rev:
            aa = True
            break

    if aa == False:    
        for j in range(len(pro)):
            if pro[j] in rev:
                pro[j] = afe[rev.index(save[j])]
        pro.reverse()
        out = ''
        for j in range(len(save)):
            out += pro[j]
        if save == out:
            counter += 1
    else:
        continue
print(counter)
