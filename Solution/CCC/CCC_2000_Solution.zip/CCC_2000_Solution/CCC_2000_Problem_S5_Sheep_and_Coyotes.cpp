// CCC_2000_Problem_S5_Sheep_and_Coyotes
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll distance(ll a, ll i, ll b){
    return (a-i)*(a-i) + b*b;
}
int main(){
    int n;
    vector<int>sheepx;
    vector<int>sheepy;
    vector<int>pos;
    int mindis;
    double x,y;
    cin >> n;
    bool eaten[n];
    for (int i=0; i<n; i++){
        cin >> x >> y;
        sheepx.push_back((int)(x*500));
        sheepy.push_back((int)(y*500));
        eaten[i] = false;
    }
    for (int i=0; i<250000; i++){
        ll mindis = 1234567890123456;
        pos.clear();
        for (int j=0; j<n; j++){
            ll dis = distance((ll)sheepx[j],(ll)i,(ll)sheepy[j]);
            if (dis < mindis){
                mindis = dis;
                pos.clear();
                pos.push_back(j);
            }
            else if(dis == mindis){
                pos.push_back(j);
            }
        }
        for (int j=0; j<pos.size(); j++){
            eaten[pos[j]] = true;
        }
    }
    cout << fixed << setprecision(2);
    for (int i=0; i<n; i++){
        if (eaten[i]) cout << "The sheep at (" << (double) sheepx[i]/500 << ", " << (double) sheepy[i]/500 << ") might be eaten." << endl;
    }
    return 0;
}
