// CCC_2000_Problem_S1_Slot_Machines
#include <iostream>

using namespace std;

int main() {
    int total;
    cin >> total;
    int one;
    cin >> one;
    int two;
    cin >>  two;
    int three;
    cin >> three;
    int counter = 0;
    while (total != 0){
        one++;
        counter++;
        total--;
        if (one == 35){
            one = 0;
            total += 30;
        }
        if (total == 0){
            cout << "Martha plays ";
            cout << counter;
            cout << " times before going broke.";
            break;
        }

        two++;
        counter++;
        total--;
        if (two == 100){
            two = 0;
            total += 60;
        }
        if (total == 0){
            cout << "Martha plays ";
            cout << counter;
            cout << " times before going broke.";
            break;
        }
        three++;
        counter++;
        total--;
        if (three == 10){
            three = 0;
            total += 9;
        }
        if (total == 0){
            cout << "Martha plays ";
            cout << counter;
            cout << " times before going broke.";
            break;
        }

    }
    return 0;
}
