// CCC_2000_Problem_J1_Calendar
#include <iostream>
using namespace std;

int main() {
  int start;
  cin >> start;
  int total;
  cin >> total;
  cout << "Sun Mon Tue Wed Thr Fri Sat"<< endl;

  int counter = 0;
  for (int i = 1; i <= total+start-1; i++){
    counter++;
    if (i < start){
        printf("   ");
    }
    else{
        printf("%3d",i-start+1);
    }

    if (counter % 7 == 0){
        printf("\n");
    }
    else{
        if (i == total+start-1){
            printf("\n");
            break;
        }
        printf(" ");
    }
  }
  return 0;
}
