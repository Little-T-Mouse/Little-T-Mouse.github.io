# CCC_2000_Problem_S4_Golf
import sys
goal = int(input())
n = int(input())
golf = []
way = [0 for i in range(goal)]
for i in range(n):
    tmp = int(input())
    golf.append(tmp)
    way[tmp-1] = 1
total = 0
golf.sort()
for i in range(goal):
    if way[i] == 0:
        continue
    for j in range(n):
        if i+golf[j] < goal and way[i+golf[j]] == 0:
            way[i+golf[j]] = way[i]+1
        if i+golf[j] == goal-1:
            print("Roberta wins in",(way[goal-1]),"strokes.")
            sys.exit()
print("Roberta acknowledges defeat.")
