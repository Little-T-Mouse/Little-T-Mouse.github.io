# CCC_2000_Problem_S3_Surfing
import queue
def bfs(graph, V, x, target):
    found_target = False
    level = [None] * V  
    visited = [False] * V  
    que = queue.Queue() 
    que.put(x)  
    level[x] = 0
    maxlevel = level[x]
    visited[x] = True
    while (not que.empty()): 
        x = que.get()  
        for i in range(len(graph[x])):
            b = web.index(graph[x][i])
            if not visited[b]:
                que.put(b)
                level[b] = level[x] + 1
                visited[b] = True
                if b == target:
                    found_target = True
                    return(found_target)
    return(found_target)


n = int(input())
V = n
graph = [[] for i in range(V)]
con = []
web = []
for i in range(n):
    connect = []
    web.append(input())
    while True:
        temp = input()
        if temp == "</HTML>":
            break
        if "HREF" in temp:
            d = temp.count("HREF")
            for g in range(d):
                a = int(temp.index("HREF"))
                for j in range(a+7,len(temp),1):
                    if temp[j] == '"':
                        h = j
                        break
                tem = ''
                for k in range(a+6,h):
                    tem += temp[k]
                connect.append(tem)
                print("Link from "+web[i]+" to "+tem)
                temp = temp.replace("HREF","####",1)
                graph[i].append(tem)
    con.append(connect)
test = []
while True:
    te = input()
    if te == "The End":
        break
    else:
        ta = input()
        tog = (te,ta)
        test.append(tog)
for i in range(len(test)):
    e = web.index(test[i][0])
    f = web.index(test[i][1])
    answer = bfs(graph, V, e, f)
    if answer == True:
        print("Can surf from "+test[i][0]+" to "+test[i][1]+".")
    else:
        print("Can't surf from "+test[i][0]+" to "+test[i][1]+".")
